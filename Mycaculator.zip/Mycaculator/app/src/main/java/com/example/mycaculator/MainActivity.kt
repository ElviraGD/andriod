package com.example.mycaculator

import android.R
import android.os.Bundle

import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    private var show_equation =
        StringBuilder() //显示运算式个private StringBuilder的字符串。每按一个按钮，只要满足要求，不是错误的输入，就调用append()方法，将按钮的值当字符存入这个字符串中
    private var calculate_equation //计算式
            : ArrayList<*>? = null
    private var signal = 0 //为0 时表示刚输入状态；为1 时表示当前在输出结果上继续输入
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //初始化
        show_equation = StringBuilder()
        calculate_equation = ArrayList<Any?>()
        val zero =
            findViewById<View>(R.id.zero) as Button
        val one =
            findViewById<View>(R.id.one) as Button
        val two =
            findViewById<View>(R.id.two) as Button
        val three =
            findViewById<View>(R.id.three) as Button
        val four =
            findViewById<View>(R.id.four) as Button
        val five =
            findViewById<View>(R.id.five) as Button
        val six =
            findViewById<View>(R.id.six) as Button
        val seven =
            findViewById<View>(R.id.seven) as Button
        val eight =
            findViewById<View>(R.id.eight) as Button
        val nine =
            findViewById<View>(R.id.nine) as Button
        val cls =
            findViewById<View>(R.id.cls) as Button
        val div =
            findViewById<View>(R.id.div) as Button
        val mul =
            findViewById<View>(R.id.mul) as Button
        val backspace =
            findViewById<View>(R.id.Backspace) as Button
        val sub =
            findViewById<View>(R.id.sub) as Button
        val add =
            findViewById<View>(R.id.add) as Button
        val equal =
            findViewById<View>(R.id.equal) as Button
        val point =
            findViewById<View>(R.id.spot) as Button
        val result = findViewById<View>(R.id.result) as EditText
        result.isCursorVisible = true //android:cursorVisible设定光标为显示/隐藏，默认显示
        //        disableShowInput(result);
        zero.setOnClickListener {
            if (show_equation.toString() != "0") { //将stringBuilder对象通过调用toString()方法转换为String对象并与0比较是否相等
                if (signal == 0) {
                    show_equation.append("0") //将0追加至运算式末尾
                    result.setText(show_equation) //文本框显示运算式
                    result.setSelection(result.text.length) //将光标追踪到内容的最后
                } else {
                    show_equation.delete(0, show_equation.length) //如果在结果上接着输入数字则将文本框内容清除
                    show_equation.append("0")
                    result.setText(show_equation)
                    result.setSelection(result.text.length)
                    signal = 0
                }
            }
        }
        one.setOnClickListener {
            if (signal == 0) {
                show_equation.append("1")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("1")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        two.setOnClickListener {
            if (signal == 0) {
                show_equation.append("2")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("2")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        three.setOnClickListener {
            if (signal == 0) {
                show_equation.append("3")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("3")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        four.setOnClickListener {
            if (signal == 0) {
                show_equation.append("4")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("4")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        five.setOnClickListener {
            if (signal == 0) {
                show_equation.append("5")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("5")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        six.setOnClickListener {
            if (signal == 0) {
                show_equation.append("6")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("6")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        seven.setOnClickListener {
            if (signal == 0) {
                show_equation.append("7")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("7")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        eight.setOnClickListener {
            if (signal == 0) {
                show_equation.append("8")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("8")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        nine.setOnClickListener {
            if (signal == 0) {
                show_equation.append("9")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append("9")
                result.setText(show_equation)
                result.setSelection(result.text.length)
                signal = 0
            }
        }

        //清除文本框内容
        cls.setOnClickListener {
            show_equation.delete(0, show_equation.length) //清除文本框内容
            calculate_equation.clear()
            signal = 0
            result.setText("")
        }

        //删除运算式最后一个字符
        backspace.setOnClickListener {
            if (show_equation.toString() != "") {
                if (signal == 0) {
                    show_equation.deleteCharAt(show_equation.length - 1) //删除运算式最后一个字符
                    result.setText(show_equation)
                    result.setSelection(result.text.length)
                } else {
                    show_equation.delete(0, show_equation.length)
                    result.setText("")
                    signal = 0
                }
            }
        }
        point.setOnClickListener {
            if (signal == 0) {
                val a = show_equation.toString()
                if (a == "") {
                    show_equation.append(".")
                    result.setText(show_equation)
                    result.setSelection(result.text.length)
                } else {
                    var i: Int
                    var t = '0'
                    i = a.length
                    while (i > 0) {
                        t = a[i - 1]
                        if (t == '.' || t == '+' || t == '-' || t == '*' || t == '/') break
                        i--
                    }
                    if (i == 0) {
                        show_equation.append(".")
                        result.setText(show_equation)
                        result.setSelection(result.text.length)
                    } else if (t == '+' || t == '-' || t == '*' || t == '/') {
                        show_equation.append(".")
                        result.setText(show_equation)
                        result.setSelection(result.text.length)
                    }
                }
            } else {
                show_equation.delete(0, show_equation.length)
                show_equation.append(".")
                result.setText(".")
                result.setSelection(result.text.length)
                signal = 0
            }
        }
        equal.setOnClickListener { //判断用户是否输入了内容
            if (show_equation.toString() != "") {
                signal = 1
                val temp = show_equation[show_equation.length - 1]
                if (show_equation[0] == '-') show_equation.insert(0, "0")
                if (temp == '+' || temp == '-') show_equation.append("0")
                if (temp == '*' || temp == '/') show_equation.append("1")
                val temp1 = StringBuilder()
                for (i in 0 until show_equation.length) {
                    if (show_equation[i] >= '0' && show_equation[i] <= '9' || show_equation[i] == '.'
                    ) {
                        temp1.append(show_equation[i].toString())
                    } else {
                        calculate_equation.add(temp1.toString())
                        temp1.delete(0, temp1.length)
                        calculate_equation.add(show_equation[i].toString())
                    }
                }
                calculate_equation.add(temp1.toString())
                calculate_equation.add("#")
                val temp8 = calculate(calculate_equation)
                result.setText(temp8)
                result.setSelection(result.text.length)
                show_equation.delete(0, show_equation.length)
                calculate_equation.clear()
                show_equation.append(temp8)
            }
        }
        add.setOnClickListener { //判断用户是否输入了内容
            if (show_equation.toString() != "") {
                signal = 0
                val temp = show_equation[show_equation.length - 1]
                if (temp == '+' || temp == '-' || temp == '*' || temp == '/') {
                    show_equation.deleteCharAt(show_equation.length - 1)
                    show_equation.append("+")
                } else show_equation.append("+")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            }
        }
        sub.setOnClickListener { //判断用户是否输入了内容
            if (show_equation.toString() != "") {
                signal = 0
                val temp = show_equation[show_equation.length - 1]
                if (temp == '+' || temp == '-' || temp == '*' || temp == '/') {
                    show_equation.deleteCharAt(show_equation.length - 1)
                    show_equation.append("-")
                } else show_equation.append("-")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            }
        }
        mul.setOnClickListener { //判断用户是否输入了内容
            if (show_equation.toString() != "") {
                signal = 0
                val temp = show_equation[show_equation.length - 1]
                if (temp == '+' || temp == '-' || temp == '*' || temp == '/') {
                    show_equation.deleteCharAt(show_equation.length - 1)
                    show_equation.append("*")
                } else show_equation.append("*")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            }
        }
        div.setOnClickListener { //判断用户是否输入了内容
            if (show_equation.toString() != "") {
                signal = 0
                val temp = show_equation[show_equation.length - 1]
                if (temp == '+' || temp == '-' || temp == '*' || temp == '/') {
                    show_equation.deleteCharAt(show_equation.length - 1)
                    show_equation.append("/")
                } else show_equation.append("/")
                result.setText(show_equation)
                result.setSelection(result.text.length)
            }
        }
    }

    //运算符优先级
    protected fun operatorPriorityCompare(
        operator1: Char,
        operator2: Char
    ): Boolean {
        var o1 = 0
        var o2 = 0
        when (operator1) {
            '+' -> {
                o1 = 0
            }
            '-' -> {
                o1 = 0
            }
            '*' -> {
                o1 = 1
            }
            '/' -> {
                o1 = 1
            }
        }
        when (operator2) {
            '+' -> {
                o2 = 0
            }
            '-' -> {
                o2 = 0
            }
            '*' -> {
                o2 = 1
            }
            '/' -> {
                o2 = 1
            }
        }
        return if (o1 <= o2) {
            false
        } else true
    }

    //计算
    protected fun calculate(equation: ArrayList<*>): String {
        var temp2: Double
        var temp3: Double
        var result: Double
        val operator: ArrayList<*> = ArrayList<Any?>() //运算符
        val operand: ArrayList<*> = ArrayList<Any?>() //操作数
        for (i in equation.indices) {
            val temp4 = equation[i] as String //temp4=运算符
            if (temp4 == "+" || temp4 == "-" || temp4 == "*" || temp4 == "/") {
                if (operator.size > 0) {
                    var temp5 = operator[operator.size - 1].toString()
                    while (!operatorPriorityCompare(
                            temp4[0],
                            temp5[0]
                        ) && operator.size > 0
                    ) {
                        operator.removeAt(operator.size - 1)
                        //取得两个操作数temp2,temp3
                        temp3 = operand[operand.size - 1].toString().toDouble()
                        operand.removeAt(operand.size - 1)
                        temp2 = operand[operand.size - 1].toString().toDouble()
                        operand.removeAt(operand.size - 1)
                        when (temp5[0]) {
                            '+' -> {
                                result = Add(temp2, temp3)
                                operand.add(result.toString())
                            } //String.valueOf()方法会首先对转换的对象进行判空检测，如果为空，则返回“null”字符串
                            '-' -> {
                                result = Sub(temp2, temp3)
                                operand.add(result.toString())
                            } //将结果追加到操作数组尾部
                            '*' -> {
                                result = Mul(temp2, temp3)
                                operand.add(result.toString())
                            }
                            '/' -> {
                                result = Div(temp2, temp3)
                                operand.add(result.toString())
                            }
                        }
                        temp5 = if (operator.size > 0) {
                            operator[operator.size - 1].toString()
                        } else break
                    }
                    operator.add(temp4)
                } else operator.add(temp4)
            } else if (temp4 == "#") {
                while (operator.size > 0) {
                    val temp6 = operator[operator.size - 1] as String
                    operator.removeAt(operator.size - 1)
                    temp3 = operand[operand.size - 1].toString().toDouble()
                    operand.removeAt(operand.size - 1)
                    temp2 = operand[operand.size - 1].toString().toDouble()
                    operand.removeAt(operand.size - 1)
                    when (temp6[0]) {
                        '+' -> {
                            result = Add(temp2, temp3)
                            operand.add(result.toString())
                        }
                        '-' -> {
                            result = Sub(temp2, temp3)
                            operand.add(result.toString())
                        }
                        '*' -> {
                            result = Mul(temp2, temp3)
                            operand.add(result.toString())
                        }
                        '/' -> {
                            result = Div(temp2, temp3)
                            operand.add(result.toString())
                        }
                    }
                }
            } else {
                operand.add(temp4)
            }
        }
        return operand[0].toString()
    }

    companion object {
        //相加
        fun Add(d1: Double, d2: Double): Double {
            return d1 + d2
        }

        //相减
        fun Sub(d1: Double, d2: Double): Double {
            return d1 - d2
        }

        //相乘
        fun Mul(d1: Double, d2: Double): Double {
            return d1 * d2
        }

        //相除
        fun Div(d1: Double, d2: Double): Double {
            return d1 * 1.0 / d2
        }
    }
}