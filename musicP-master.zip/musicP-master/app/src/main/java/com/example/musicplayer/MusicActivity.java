package com.example.musicplayer;

import android.content.ClipData;
import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;

import com.example.musicplayer.MainActivity;

import java.util.ArrayList;
import java.util.List;

public class MusicActivity extends AppCompatActivity {
    String path;
    String presongPath;
    String nextsongPath;
    TextView title;
    SongInfo songName;
    MediaPlayer mediaPlayer=new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        Intent intent = getIntent();
         path = intent.getStringExtra("path");
         presongPath = intent.getStringExtra("presongpath");
         nextsongPath = intent.getStringExtra("nextsongpath");
         title = findViewById(R.id.name);
        songName = new SongInfo();


        Button startbutton = (Button)findViewById(R.id.start);
        Button pausebutton = (Button)findViewById(R.id.pause);
        Button prebutton = (Button)findViewById(R.id.pre);
        Button nextbutton = (Button)findViewById(R.id.next);
        Button downloadbutton = (Button) findViewById(R.id.download);




        title.setText(songName.getSongName());


        //播放
        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play(path);

            }
        });

        //暂停
        pausebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }else{
                    mediaPlayer.start();
                }
            }
        });

        //播放下一曲[
        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("MusicActivite","nextSong");
               play(nextsongPath);

            }
        });

        //播放上一曲
        prebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play(presongPath);
            }
        });

//        下载
        downloadbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(MusicActivity.this,WebViewActivity.class);

                startActivity(intent);
            }
        });

    }



    //播放
    public void play(String path)
    {
        try{

            mediaPlayer.reset();

            mediaPlayer.setDataSource(path);
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaP) {
                    mediaP.start();
                }
            });


        }catch (Exception e){
            Log.v("MusicService", e.getMessage());
            }

    }

    //    右上角添加菜单栏
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

//    对设置按钮进行配置
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
                        case R.id.setting_item:
                Toast.makeText(this, "You clicked 设置", Toast.LENGTH_SHORT).show();
                break;

            default:
        }
        return true;
    }

}
