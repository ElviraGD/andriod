package com.example.musicplayer;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebViewClient;

public class WebView extends AppCompatActivity
{

    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);

    }

    
}
